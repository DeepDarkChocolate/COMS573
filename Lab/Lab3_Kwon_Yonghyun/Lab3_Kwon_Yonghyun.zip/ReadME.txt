Version used:
Python 3.7.4

The name and version of additional packages:
Numpy version = 1.16.5
Pandas version = 0.25.1
arff version = 2.4.0
python-weka-wrapper3 version = 0.1.12
javabridge version = 1.0.18

How to run my code and reproduce my experiments in Windows command line:
python main.py