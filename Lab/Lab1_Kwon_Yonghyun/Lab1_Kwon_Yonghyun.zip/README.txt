Version used:
Python 3.7.4

The name and version of additional packages:
Numpy version:  1.16.5