Version used:
Python 3.7.4

The name and version of additional packages:
Numpy version = 1.16.5
Pandas version = 0.25.1
Sklearn version = 0.22.2.post1

How to run my code and reproduce my experiments in Windows command line:
python main.py